def p(g):
  return [[*map(float,r)] for r in g[::-1]]
