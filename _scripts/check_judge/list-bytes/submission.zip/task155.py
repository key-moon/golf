def p(g):
  return [*map(bytes,g[::-1])]
