def p(g):
  return [map(int,r)for r in g[::-1]]
