def p(g):
 for j,c in enumerate(zip(*g[:-1])):
  if len(g)-1-c.count(0)&1:g[-1][j]=4
 return g