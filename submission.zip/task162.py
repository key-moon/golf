def p(g,R=range(18)):
 for i in R:
  a,b,c=g[i:i+3]
  for j in R:
   k=j+3
   if sum(a[j:k]+b[j:k]+c[j:k])==0:a[j:k]=b[j:k]=c[j:k]=[1]*3
 return g