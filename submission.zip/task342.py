def p(g):
 r,c=next((i,j)for i in range(9)for j in range(9)if g[i][j]==g[i][j+1]==g[i+1][j]==g[i+1][j+1]==8)
 h=[[0]*10 for _ in g]
 for i in range(10):
  for j in range(10):
   v=g[i][j]
   if v&7:h[r+(i>r)][c+(j>c)]=v
 return h