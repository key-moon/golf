def p(g):
 from collections import Counter as C;g=[[k]for k,_ in C(sum(g,[])).most_common()if k];return g