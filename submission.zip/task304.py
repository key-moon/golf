def p(g):
 s=sum(g,[]);t=max(s,key=s.count);return[[g[i%3][j%3]if g[i//3][j//3]==t else 0 for j in range(9)]for i in range(9)]