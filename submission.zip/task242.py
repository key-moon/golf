A=range
def p(g):B=next(i for(i,r)in enumerate(g)if 0 in r);C=g[B].index(0);D=len(g);return[[g[B+i][D-C-j-1]for j in A(3)]for i in A(3)]