def p(g):
 *r,=eval("[0]*3,"*3)
 for i in range(sum(sum(g,[]))//8):r[int(.7*i)][i*2%3]=1
 return r