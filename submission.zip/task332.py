def	p(g):
	t=len(g[0])&1^1
	for	r	in	g:
		for(j,v)in	enumerate(r):r[j]=v-2*(v==5and	j&1==t)
	return	g