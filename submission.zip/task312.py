def p(g):
 for r in g:
  for(i,x)in enumerate(r):
   if x==5:r[i]=r[0]
 return g