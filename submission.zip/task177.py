A=filter
p=lambda g:[*A(len,[[*A(int,s)][::-1]for s in g])]