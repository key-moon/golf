A=len
def p(g):return[[5]*A(r)if A({*r})<2else[0]*A(r)for r in g]