A=enumerate
def p(g):B=g[~-len(g)][0];return[[B*(D and(C<~-len(g)or A))for(A,D)in A(D)]for(C,D)in A(g)]