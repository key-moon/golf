A=enumerate
def p(g):B=max(max(A)for A in g);return[[C*A%B+1for(A,_)in A(D)]for(C,D)in A(g)]