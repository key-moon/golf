def p(g):
 u=[]
 w=len(g[r:=0])
 for s in g:
  r|=0==len(u)and s[-1]==2
  if r:s.reverse()
  if s[0]==2:
   u+=[k:=[*s,8].index(8)]
   if k<w:s[1:k+1]=[8]*~-k+[4]
  if s[-1]==2 and u.pop(0)<w:s[:w-1]=[8]*(w-1)
  if r:s.reverse()
 return g