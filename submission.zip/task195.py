A=range
def	p(g):s,w=[i	for(i,v)in	enumerate(sum(g,[]))if	v],len(g[0]);y,x=min(i//w	for	i	in	s),min(i%w	for	i	in	s);return[[g[y+i][x+j]&g[y+i%3*3][x+j%3*3]for	j	in	A(9)]for	i	in	A(9)]