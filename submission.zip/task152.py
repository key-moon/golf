def p(g):
    a=[r+r[::-1]for r in g]
    return a+a[::-1]