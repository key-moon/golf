def p(g):
  A=[0]
  for C in g[::-1]:
    if D:=sum(A):
      C.insert(0,C.pop([-1,A.index(B:=max(A))][D//B!=2]))
    A=C
  return g