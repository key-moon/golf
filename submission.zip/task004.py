def p(g):
  C=[0]
  for A in g[::-1]:
    if B:=sum(C):
      A.insert(0,A.pop([-1,C.index(D:=max(C))][B//D!=2]))
    C=A
  return g