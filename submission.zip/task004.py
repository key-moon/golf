def p(g):
 AC=[0]
 for AB in g[::-1]:
  if AD:=sum(AC):AB.insert(0,AB.pop([-1,AC.index(AA:=max(AC))][AD//AA!=2]))
  AC=AB
 return g