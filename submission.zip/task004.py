def p(g):
  A=[0]
  for D in g[::-1]:
    if C:=sum(A):
      B=max(A);D.insert(0,D.pop([-1,A.index(B)][C//B!=2]))
    A=D
  return g