def p(g):
 C=[0]
 for B in g[::-1]:
  if D:=sum(C):B.insert(0,B.pop([-1,C.index(A:=max(C))][D//A!=2]))
  C=B
 return g