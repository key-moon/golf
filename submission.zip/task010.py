def p(g):
 d={}
 for r in g:
  for(c,v)in enumerate(r):
   if v==5:r[c]=d.setdefault(c,len(d)+1)
 return g