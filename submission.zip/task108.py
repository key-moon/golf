A=range
def	p(g):return[[g[i//4*2+1][j//4*2+1]for	j	in	A(len(g)*2)]for	i	in	A(len(g)*2)]