A=len
def	p(g):B=g[0];a=[0]+B+[0];C=[a[i]or	a[i+2]for	i	in	range(A(B))];return([B,C]*(A(g)//2+1))[:A(g)]