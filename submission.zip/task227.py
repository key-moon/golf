A=range
p=lambda	g:[[2*(g[i][j]==0==g[i+4][j])for	j	in	A(4)]for	i	in	A(4)]