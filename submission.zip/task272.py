def p(g):
 for i,r in enumerate(g):
  for j,v in enumerate(r):
   if v==2 and not(i and g[i-1][j]==2 or i<len(g)-1 and g[i+1][j]==2 or j and r[j-1]==2 or j<len(r)-1 and r[j+1]==2):r[j]=1
 return g