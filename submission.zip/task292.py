def	p(g):
	for	r	in	g:r[::3]=[6if	v==4else	v	for	v	in	r[::3]]
	return	g