def	p(g):
	n=len(g)
	for	_	in[0]*2:*g,=map(list,zip(*[{*s[1:n-1]}&{2,8}and	s	or[s[0],*[3]*(n-2),s[-1]]for	s	in	g]))
	return	g