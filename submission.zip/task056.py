A=range
def p(g):return[[{171:1,341:2,118:3,186:6}[sum(1<<i*3+j for i in A(3)for j in A(3)if g[i][j])]]]