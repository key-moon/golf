A=sorted
p=lambda	g:A(map(A,g))