def p(g):
 for r in g:
  for i in range(len(r)-2):
   if r[i]==r[i+2]==1 and not r[i+1]:r[i+1]=2
 return g