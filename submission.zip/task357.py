def p(g):
 n=len(g[0]);m=n-1;p=2*m;k=(m-len(g)+1)%p
 for i in range(len(g)):
  j=abs((i+k)%p-m);g[i]=[8]*n;g[i][j]=1
 return g