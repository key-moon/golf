def p(g):
 x=[j for j,v in enumerate(g[0])if v==5]
 [r.__setitem__(j,2) for r in g if r[-1]==5 for j in x]
 return g