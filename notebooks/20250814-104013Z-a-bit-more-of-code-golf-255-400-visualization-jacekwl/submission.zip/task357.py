def p(j,A=range,c=len):
	E,k=c(j),c(j[0]);j=[[8 for W in W]for W in j];W=[W for W in range(k)];W+=W[::-1][1:-1]
	while c(W)<E:W+=W[:]
	for l in A(E):j[-(l+1)][W[l]]=1
	return j