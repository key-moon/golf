def p(g):
	C=range;A=len(g);D=A//2-2;E=[];I=[g[0][0],g[0][-1],g[-1][0],g[-1][-1]]
	for F in C(2,A-2):
		G=[]
		for H in C(2,A-2):
			B=g[F][H]
			if B==8:J=(F-2)//D;K=(H-2)//D;B=I[J*2+K]
			G.append(B)
		E.append(G)
	return E