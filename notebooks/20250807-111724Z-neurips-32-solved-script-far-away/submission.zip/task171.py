def p(g,K=range):
	C=len(g);D=len(g[0]);E=[[0 for A in K(D)]for A in K(C)]
	for A in K(C):
		for B in K(D):
			if A==0 or A==C-1 or B==0 or B==D-1:E[A][B]=8
			else:E[A][B]=0
	return E