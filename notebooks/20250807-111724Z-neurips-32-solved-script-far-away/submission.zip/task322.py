def p(m,g=range):
 for c in g(len(m[0])):
  for r in g(len(m)):
   if m[r][c]:break
  else:continue
  for i in g(r,len(m)):m[i][c]=m[r][c]
 return m