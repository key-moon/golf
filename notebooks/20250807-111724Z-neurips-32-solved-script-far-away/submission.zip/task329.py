def p(g):
	A=len(g[0])//2;B=[[0 for A in A]for A in g]
	for C in range(len(g)):B[C][A]=g[C][A]
	return B