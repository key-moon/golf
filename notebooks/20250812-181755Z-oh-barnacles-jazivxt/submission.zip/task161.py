def p(g,L=len,R=range):
 h,w,d=L(g),L(g[0]),{}
 for r in R(h):
  for c in R(w):
    C=g[r][c]
    if C in d:
     d[C]['r']+=[r]
     d[C]['c']+=[c]
    else:
     d[C]={'r':[r],'c':[c]}
 X=sorted([[len(d[k]['c']),k] for k in d if k>0])[0][1]
 g=[[X if C==X else 0 for C in R] for R in g]
 for r in R(h):
  if g[r][0]==X or g[r][-1]==X: 
   for c in R(w):g[r][c]=X
 for c in R(w):
  if g[0][c]==X or g[-1][c]==X: 
   for r in R(h):g[r][c]=X
 return g