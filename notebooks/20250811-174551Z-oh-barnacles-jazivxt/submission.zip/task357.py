def p(g):
 d='[BUUUUaoaGhowowowowobNPPPPPPPPcocGhbouhmnjhbouhmnjhbodNQQQQQQQQcaocaGvjnwdodwunmvjnwdodbNKlllllllogGhdbokjhdmnuvmxjvmnuhdbokNgLLLLLLLLgaoggaGkRjkxmkvukndmRkjxkmvkunkdwkkokkbNgSSSSSSSScogcGvdmxuRmknjRmxuvdmnkjhkbokdNgKKKKKKKKgoggGkvmkxjkvmknuRdmxkjvkmnkuhkdbokkNLpppppppaogaGhkjndmvuxmRjxmvundwkokbNgTTTTTTTTcaogcaGRuknmkvjknmRuxdmvkjnkwkdokdbJ]'
 m='ttUcpTclSkhRctQciPMBNJ,MgpLglKH}J]]HF8GEsFDOEC"D]eCA0BzsAyIz{"ydnxmhwdhvdjuaitr[sq[r":qalpf1obhnbjmiglddkf8jf0i,1hccge[f],ebbdaac,8b,0a'
 m=[[m[i:i+2],m[i+2]]for i in range(0,len(m),3)]
 for r in m:d=d.replace(r[1],r[0])
 d=eval(d)
 for k in d:
  if k['I']==g:g=k['O'];return g