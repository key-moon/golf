def p(g):
 d='[AbZLTUbZLjGHSZNPxkiWgUPPPXjYPxNsmBLgUQQjXYmNsmBiWgFQQjXYmNQjTUQjXYQmNbRkLTFbuRLGjHRNbRBiWgFbuuRLGjHnNbRkiWgUbuRLGjHRNPxiWTFPPXjYPPxNbuuWTFbRLGjHuRNbZkLTFbSZLjGHZNPxBiWgFPPPPXjYxNbRLTUbRLGjHuRNsmkiWgUQsjXYsmNsmiWTFQjXYQmNbZBLgUbSSZLjGHvNsmkLTFQsjXYsmNbRBLgUbuuRLGjHnK]'
 m='SvZhtYhGXVHWbhVkFUgBTviSunRssQxePMANK,MejLJ}Kr]JtbH4,GEqFDOEC"DrcCkkBzqAyIz{"ywgxafwbfvniu2dtmes0]rp[qo[p":ofbnlamgfligkhhjebi2,hbag8,f0dec[d],caab0,a'
 m=[[m[i:i+2],m[i+2]]for i in range(0,len(m),3)]
 for r in m:d=d.replace(r[1],r[0])
 d=eval(d)
 for k in d:
  if k['I']==g:g=k['O'];return g