def p(g):
 for j in range(len(g[0])):
  counts = [0]*10
  for i in range(len(g)):
   counts[g[i][j]] += 1
  mode = counts[1:].index(max(counts[1:])) + 1
  for i in range(len(g)):
   g[i][j] = mode
 return g
