def p(g,v=range):
 h,w=len(g),len(g[0])
 D=[[0]*w for _ in v(h)]
 for i in v(h):
  for j in v(w):E,L=(i--2)%h,(j--3)%w;D[i][j]=g[E][L]
 return D