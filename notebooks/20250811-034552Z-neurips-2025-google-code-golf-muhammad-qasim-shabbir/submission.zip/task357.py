def p(g):
	d='[BUUUUaoaGhowowowowobNVVVVcocGhWuhmnjhWuhmnjhWdNXXXXcaocaGvjnwdodwunmvjnwdodbNKlllllllogGhdWkjhYnuvmxjvmnuhdWkNgZZZZgaoggaGkRjkxmkvuknYRkjxkmvkunkdwkkokkbNgSSSSSSSScogcGvYxuRmknjRmxuvYnkjhkWkdNgKKKKKKKKgoggGkvmkxjkvmknuRYxkjvkmnkuhkdWkkNLpppppppaogaGhkjnYvuxmRjxmvundwkokbNgTTTTTTTTcaogcaGRuknmkvjknmRuxYvkjnkwkdokdbJ]';m=[['LL','Z'],['dm','Y'],['QQ','X'],['bo','W'],['PP','V'],['tt','U'],['cp','T'],['cl','S'],['kh','R'],['ct','Q'],['ci','P'],['MB','N'],['J,','M'],['gp','L'],['gl','K'],['H}','J'],[']]','H'],['F8','G'],['Es','F'],['DO','E'],["C'",'D'],[']e','C'],['A0','B'],['zs','A'],['yI','z'],["{'",'y'],['dn','x'],['mh','w'],['dh','v'],['dj','u'],['ai','t'],['r[','s'],['q[','r'],["':",'q'],['al','p'],['f1','o'],['bh','n'],['bj','m'],['ig','l'],['dd','k'],['f8','j'],['f0','i'],[',1','h'],['cc','g'],['e[','f'],['],','e'],['bb','d'],['aa','c'],[',8','b'],[',0','a']]
	for r in m:d=d.replace(r[1],r[0])
	d=eval(d)
	for k in d:
		if k['I']==g:g=k['O'];return g