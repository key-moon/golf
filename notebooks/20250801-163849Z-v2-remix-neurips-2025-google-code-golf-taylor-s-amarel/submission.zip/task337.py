def p(g):
 m={1:1,2:2,3:3,4:4,5:8,6:6,7:7,8:5,9:9}
 return[[m.get(x,x)for x in r]for r in g]