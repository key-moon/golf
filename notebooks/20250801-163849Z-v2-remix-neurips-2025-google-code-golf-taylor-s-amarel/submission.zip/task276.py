def p(g):
 m={6:2,7:7}
 return[[m.get(x,x)for x in r]for r in g]