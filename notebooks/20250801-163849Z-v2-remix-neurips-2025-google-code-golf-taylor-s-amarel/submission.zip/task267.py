def p(g):
 m={0:0,2:4,3:6,4:0,6:0}
 return[[m.get(x,x)for x in r]for r in g]