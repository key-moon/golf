def p(g):
 m={1:1,7:5,8:8}
 return[[m.get(x,x)for x in r]for r in g]