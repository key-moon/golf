def p(g):
  
    first_mapping = {5: 0, 3: 1, 7: 2}  
    
   
    new_first = first_mapping.get(g[0][0], 0)
    
   
    return [[new_first]] + [g[3]] + [g[4]] + [g[2]] + [g[3]] + [g[4]]

#
