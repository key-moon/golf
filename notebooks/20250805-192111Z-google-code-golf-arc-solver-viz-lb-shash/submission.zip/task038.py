def p(g,u=range,P=0):
 for r in u(len(g)-1):
  for c in u(len(g[0])-1):
    q=g[r][c:c+2]+g[r+1][c:c+2]
    if q==[1]*4:P+=1
 return[[0 if i+1>P else 1 for i in u(5)]]