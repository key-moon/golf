def p(g,R=range(4)):
 for i in R:
  for j in R:g[i][j]+=g[i+5][j]
 g=[[3 if C>0 else 0 for C in R]for R in g]
 return g[:4]