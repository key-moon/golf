def p(g,R=range(3)):
 for r in R:
  for c in R:
   g[r][c]+=g[r+3][c]
   if g[r][c]>0:g[r][c]=0
   else:g[r][c]=2
 return g[:3]