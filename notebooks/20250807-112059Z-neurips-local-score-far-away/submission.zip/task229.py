from collections import*
def p(g):X=[x for R in g for x in R];C=Counter(X).most_common(1);c=C[0][0];g=[[C if C==c else 5 for C in R]for R in g];return g