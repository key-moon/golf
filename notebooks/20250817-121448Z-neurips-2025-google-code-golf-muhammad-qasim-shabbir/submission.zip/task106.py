def p(g):
 X=[]
 F=[list(r)for r in zip(*g[::-1])]
 m=[list(r)for r in zip(*F[::-1])]
 N=[list(r)for r in zip(*m[::-1])]
 for r in range(len(g)):X.append(g[r]+F[r])
 for r in range(len(g)):X.append(N[r]+m[r])
 return X