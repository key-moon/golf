def p(g):
 S=[[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0]]
 for r in range(5):
  for c in range(3):
   if g[r][c]==0 and g[r][c+4]==0:S[r][c]=8
 return S