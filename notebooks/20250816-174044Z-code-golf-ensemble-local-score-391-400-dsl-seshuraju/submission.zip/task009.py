#coding:L1
import zlib
exec(zlib.decompress(bytes("""xÚ1o0gømåÒt"Å°g°n0Á ãT4ýù56Mºt±OÏï»{¾ÖtìpÀI»ÞÀ­q"O#*©rênlpl¤â'<óQ?TF¢°¸ÜêÒäé;ðËAGádèØ¨$)M6?®¥-~Äl1ûio^)ÿÄ³ÌvVKÐâ%ÄKílCk¼Õê?Ì+3n ¹ÛÃö)¡ÆÊ7)h}¡)¨¾óØDKà»È_Çkh\\õW(v{j&Õ`7ÖÓ5b»¡û_z&ÒKéTèÿí{]ä{æÑuÝi2ûcr¬ü¡[""","L1")))