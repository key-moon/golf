#coding:L1
import zlib
exec(zlib.decompress(bytes("""xÚu¿Â ÆwâFHl"º5aèÀ3t \rSP0hßß»Óêøý¹ïw£pçQ´:U|ñºú­L1­\r¥B)C´H$K;:)@4Òd:yDåÓF?æ¦'zè¸<¸F
]Òê÷:³5Üq±"W.*Bÿæ¦¿Ü¯dqiüÃÇâæêsÍ _k[[+""","L1")))