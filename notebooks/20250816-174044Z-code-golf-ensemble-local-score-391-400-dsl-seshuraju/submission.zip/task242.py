#coding:L1
import zlib
exec(zlib.decompress(bytes("""xÚuM
0F÷b#jJ`på6d!6F¡Ú2´Øãw?ÚBÈd^æ/WÓÁY^x-°¬	ó\x00z>óKQ1rÚTªC®4­\x00º;Â0AÍú$¹DÙ"8Ú®tv\x00¬B­Z-DïG«bä,MQFp!©´úpüÀ*úí'ö?ôs°¯L>éß`TcÖº'ó¸÷ç`8owXºa>6o*Qæ¨Bååý', y¾ã6xq""","L1")))