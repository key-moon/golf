#coding:L1
import zlib
exec(zlib.decompress(bytes("""xÚeA Ïø+8B¤Þ6Ò94M/Ú»ÂZ¬Ec»éþü%nå yóÆ7£6-HOaV®3ü
qü¢lÇ×Ø:ÜK~§y \rÉÕ{yaÃÆD&Wl{QK1Hå4©Ù@Ýø
u÷å5*±pÉâÍï{¥5Yå'þ¥ü}³Ájõ"Ã*PûiBªp|
òfj Ë)#9Ëü3c» vAÉhF\rÓ`Ò7«ÒK$>lvæ¦òqÐ8NÐ½h¤ÐàÃ4¾Áß41t`{5MÆmZ}êås-<¬#µï½í³¤¼úùGo±6ÿ 6Ö~Ð$îõo´iÎ:ZlûÁÕÊo[Z¢ð Ù¼¾gÏ¿ùÍË""","L1")))