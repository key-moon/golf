#coding:L1
import zlib
exec(zlib.decompress(bytes("""xÚ?o0Ågøíô,ÑLà!B^=bðß0PQ"*Eùîu!ªfét÷~z:½{ÚXô[823\\z3Ù8pVaØqòf@GÜ®RÞ¤§iÆö5üß|¨ÃÀoÃ8#Æi]x<ù2\r¨\r9ÑK-Ð)Æ}3`~]=èÅ×+{ú8¨ßÄA2ÖaE,PzÁI"fÑ,KX³fô=ó¤L'%o§&ÌÐüé)RçIAÝÇÂ]wê×¿%ÛoUu@}>#ã>\rÚ¯Jàt­Én8ºçîîMVQMê?åÖßÄè""","L1")))