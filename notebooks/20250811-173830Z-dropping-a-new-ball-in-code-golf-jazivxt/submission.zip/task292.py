def p(g):
 d='[wxeQszR6ZEmjkGlScQYxeRGtEmjTZaLxeUYzcD6ZTmjsGtLxWUgkzeD6XVkGZSeUgsPDGZTMTNSnQokPcRGNVjTNcaLPeQosznR6XiVjYGNaLPUgYzWD6NTMYGliLPWQodszncR6lNVmsGNcaSUsxeDGlEmjEZLPcQgdszWR6NcVjkGXLPQgszeR6NVsGZaSncUodsPWDGNcTMmTlNSWUgdsPcDGXVjENcLPcUokznD6NcTMjsGNScUdsxWDGtTmjdEliSnUosPeDGNTMjdEXiSncQoYPeRGNcVmEXlSeQgkxWRGZVEXLxWQdszcR6liEmjYGtaSWQgYPRGliVdENaLPeUoYzncD6XlVmkGNcJ]'
 m='tcZdkYllXecWEMVsyUs6TLzSaDRkyQxnPltNmmMKwLJ,KH}J]]HFfG0cFk6ECrDBOCA"B]hA0nz4oy4ixvrwuIv{"ulbtaksq[rp[q":pggoeenjjmiflh[kdfjbei],hddg,6fcceaadabc,0b,4a'
 m=[[m[i:i+2],m[i+2]]for i in range(0,len(m),3)]
 for r in m:d=d.replace(r[1],r[0])
 d=eval(d)
 for k in d:
  if k['I']==g:g=k['O'];return g