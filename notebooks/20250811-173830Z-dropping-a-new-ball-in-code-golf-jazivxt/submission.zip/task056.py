def p(g):
 d='[jE5t5u5k5C8u8k8t8u8ys5u5k5t5u5yw1,1k1,1f1Aw8,8k8,8f8As4,4t4u4k4xw5tEE5k5D8t8,8,8k8Bs7,7t7u7k7C2u2k2t2u2ys8,8t8u8k8C6,6t6u6k6xw3,3k3,3f3Aw7,7k7,7f7As6u6k6t6u6yw3t3,3,3k3D9,9k9,9f9Aw1t1,1,1k1D9t9,9,9k9D4,4k4,4f4Aw4t4,4,4k4Bs7u7k7t7u7yw6t6,6,6k6D2,2k2,2f2AwE5kE5f5As9u9k9t9u9ys1u1k1t1u1yw2t2,2,2k2D6,6k6,6f6As3u3k3t3u3ys9,9t9u9k9C3,3t3u3k3C2,2t2u2k2C4u4k4t4u4yw7t7,7,7k7Bs1,1t1u1k1xq]'
 m='5,EBwDxsCv6Bz3Abvzo2yv1xsgwbovb,ubftrjsq,rp}q]]pneomOnl"m]alfgkiejhIi{"h0,ga[fd[ec[d":c,0b],a'
 m=[[m[i:i+2],m[i+2]]for i in range(0,len(m),3)]
 for r in m:d=d.replace(r[1],r[0])
 d=eval(d)
 for k in d:
  if k['I']==g:g=k['O'];return g