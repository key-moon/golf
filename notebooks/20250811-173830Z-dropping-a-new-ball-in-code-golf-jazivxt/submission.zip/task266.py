def p(g):
 d='[njt2yFi[Czv[Ez]xgdb2]]wA3uosid2zvkwtEuoxA2uFidC]vdE]]xdb2]FiA3uvA8u]xg[2,bac]wt6yosiA2uvkwdE]oxgA2u]wdC]oxgt2y]w[Czosidb2]vkwA8uoxgd2z]wtCuosi[2,bacvkwt7yox[2,bacFit6yvt7y]xd2zFitCuvtEu]sit2yvkw[Ezo}]'
 m='oqFD7E8lDB6C3lBdaAlcz,eysjxqjw,gv,cu[atrns},rpOq,"p,komIn{"m,alf]kigjh[i":hf,gdefbce[bd0]caab0,a'
 m=[[m[i:i+2],m[i+2]]for i in range(0,len(m),3)]
 for r in m:d=d.replace(r[1],r[0])
 d=eval(d)
 for k in d:
  if k['I']==g:g=k['O'];return g