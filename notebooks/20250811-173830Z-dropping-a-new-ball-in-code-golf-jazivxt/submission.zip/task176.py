def p(g):
 d='[yLzsgqdQWaHjdEQaNQqTXeMQSjaUVzTgZQWhfYUcaVhqTvdXhQMPeYwfUhlVezTvZhcWPaYjdUQaKuczsdqdeaDlfHjEeaNQzTdZeWQaSjdUaVczTgdZhWhlfYjUeaNezTZcWeaSjEhlfKuzsqdcaDfHEcaKucqszdeDlHfEeNeqsgdXcMeSfEhlVqTdXQMhSjdaUcNqsdzdQMHjaEQVeqTgdXhcMPYjaUQVQqTvXheMPcYjdaUhNcqsgXMcHjdaEhVcqTgXhMhlYfUeKuqbdzdcDrbdaEcVQzTvdZheWPcaYwUhfNczsgdZWcaSEhfG]'
 m='qRZSwYzRXaMWNhVEPUsvTHwSdhRecQhtPKLNDtMphLJyKG,JrsHF}G]]FrjECuDBOCA"B]iAaqzxIy{"xjgwggvpeuljtbgsk4rk0qo2pn[om[n":mffli[kfbj],ieehddg,4fcdeabdaac,2b,0a'
 m=[[m[i:i+2],m[i+2]]for i in range(0,len(m),3)]
 for r in m:d=d.replace(r[1],r[0])
 d=eval(d)
 for k in d:
  if k['I']==g:g=k['O'];return g