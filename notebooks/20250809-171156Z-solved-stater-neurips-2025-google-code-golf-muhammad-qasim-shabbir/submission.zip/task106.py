def p(g):
 X=[]
 v=[list(r)for r in zip(*g[::-1])]
 n=[list(r)for r in zip(*v[::-1])]
 k=[list(r)for r in zip(*n[::-1])]
 for r in range(len(g)):X.append(g[r]+v[r])
 for r in range(len(g)):X.append(k[r]+n[r])
 return X