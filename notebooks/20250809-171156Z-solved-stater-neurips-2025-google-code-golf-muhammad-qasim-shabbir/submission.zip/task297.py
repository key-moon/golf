def p(g):
 h,w=len(g),len(g[0])
 C=g[0]*20
 for i in range(2,h):g[i]=[C[i-2]for _ in range(w)]
 return g