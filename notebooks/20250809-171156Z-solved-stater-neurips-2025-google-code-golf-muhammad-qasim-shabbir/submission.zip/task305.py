def p(j):
	A=enumerate;c=len({c for A in j for c in A if c});E=[0]*c
	for(k,W)in A(j):
		for(l,J)in A(W):
			if J:E[(k+l)%c]=J
	return[[E[(A+J)%c]for J in range(len(j[0]))]for A in range(len(j))]