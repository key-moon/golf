from collections import*
def p(g,k=range):
 C=Counter([x for r in g for x in r]).most_common(9)
 h,w=C[0][1],len(C)
 g=[[0 for _ in k(w)]for _ in k(h)]
 for i in k(w):
  for j in k(C[i][1]):g[j][i]=C[i][0]
 return g