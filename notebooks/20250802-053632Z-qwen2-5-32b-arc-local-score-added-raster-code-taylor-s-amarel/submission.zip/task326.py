def p(g):
 return[r[:2]for r in g[:2]]