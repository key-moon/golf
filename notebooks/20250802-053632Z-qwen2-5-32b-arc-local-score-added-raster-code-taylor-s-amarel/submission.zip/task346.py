def p(g):
 pattern = [r[:1] for r in g[:1]]
 return [row for _ in range(1) 
         for row in [r*1 for r in pattern]]
