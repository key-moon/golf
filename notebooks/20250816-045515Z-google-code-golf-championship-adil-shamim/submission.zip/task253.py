def p(g):
 e=[g[r][c]for r in range(len(g))for c in range(len(g[0]))if g[r][c]]
 return[[e[r*4+c]if r*4+c<len(e)else 0for c in range(4)]for r in range(4)]
