def p(g):
 g=[g[-1]]+g[:len(g)-1]
 g=[[2 if C==8 else C for C in R] for R in g]
 return g
