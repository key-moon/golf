def p(g):
 h,w=len(g),len(g[0]);n=[(r,c,v)for r in range(h)for c,v in enumerate(g[r])if v]
 if not n:return g
 o=[row[:]for row in g];rs={r for r,_,_ in n};cs={c for _,c,_ in n}
 vert=len(cs)<=1 or (len(rs)>1 and max(rs)-min(rs)<max(cs)-min(cs))
 if vert:
  pv={r:v for r,_,v in n};pt=sorted(pv.items());l=len(pt)
  if l==1:
   r,v=pt[0];o[r]=[v]*w;return o
  per=pt[-1][0]-pt[0][0]+pt[1][0]-pt[0][0]
  for r0,v in pt:
   r=r0
   while r<h:
    o[r]=[v]*w; r+=per
 else:
  pv={c:v for _,c,v in n};pt=sorted(pv.items());l=len(pt)
  if l==1:
   c,v=pt[0];[o[r].__setitem__(c,v) for r in range(h)];return o
  minc=pt[0][0];per=pt[-1][0]-pt[0][0]+pt[1][0]-pt[0][0]
  pat=[0]*per
  for c,v in pt:pat[c-minc]=v
  for r in range(h):
   for c in range(minc,w):o[r][c]=pat[(c-minc)%per]
 return o