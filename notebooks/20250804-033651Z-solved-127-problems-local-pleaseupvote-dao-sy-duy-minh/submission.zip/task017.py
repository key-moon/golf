def p(g):
 h,w=len(g),len(g[0])
 o=[r[:]for r in g]
 b={v for r in g for v in r if v}
 cs=8 in b
 hp=wp=0
 for ph in range(1,h+1):
  for pw in range(1,w+1):
   t={}
   ok=True
   for i in range(h):
    for j in range(w):
     v=g[i][j]
     if v:
      k=(i%ph,j%pw)
      if k in t and t[k]!=v:ok=False;break
      t[k]=v
    if not ok:break
   if ok and len(t)==ph*pw:
    hp,wp=ph,pw;break
  if hp:break
 if not hp:return g
 m=[[0]*wp for _ in range(hp)]
 for i in range(h):
  for j in range(w):
   v=g[i][j]
   if v:m[i%hp][j%wp]=v
 for i in range(h):
  for j in range(w):
   if o[i][j]==0:
    c=m[i%hp][j%wp]
    o[i][j]=8 if cs and c==2 else c
 return o
