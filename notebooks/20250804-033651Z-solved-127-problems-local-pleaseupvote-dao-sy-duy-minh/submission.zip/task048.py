def p(g):
 h,w =1,1
 y0=(len(g) - h)//2
 x0=(len(g[0])-w)//2
 return [r[x0:x0+w] for r in g[y0:y0+h]]
