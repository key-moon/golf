def p(g):
 return [R[:int(len(g[0])/3)] for R in g]
