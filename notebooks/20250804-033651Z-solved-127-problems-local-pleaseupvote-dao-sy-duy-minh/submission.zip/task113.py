def p(g):return g[:len(g)//2]+g[:len(g)//2][::-1]
