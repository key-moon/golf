def p(g):
 for r in range(3):
  for c in range(3):
   g[r][c]+=g[r+3][c]
   if g[r][c]>0:g[r][c]=0
   else:g[r][c]=2
 return g[:3]
