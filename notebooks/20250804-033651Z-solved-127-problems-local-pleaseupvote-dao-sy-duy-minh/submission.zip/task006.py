def p(g):
  return [[2 if g[r][c] and g[r][c+4] else 0 for c in range(3)] for r in range(3)]
