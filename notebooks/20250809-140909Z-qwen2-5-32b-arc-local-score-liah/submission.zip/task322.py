def p(m,s=range):
 for c in s(len(m[0])):
  for r in s(len(m)):
   if m[r][c]:break
  else:continue
  for i in s(r,len(m)):m[i][c]=m[r][c]
 return m