p=lambda j:[[max(sum(j,[]),key=sum(j,[]).count)]*3]*3
