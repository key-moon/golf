def p(g,L=len,R=range):
 h,w=L(g),L(g[0])
 x=g[0].count(4)+1
 y=[r[0] for r in g].count(4)+1
 #print(x,y)
 #get color sets for each block
 #copy main block and propagate to others
 return g
