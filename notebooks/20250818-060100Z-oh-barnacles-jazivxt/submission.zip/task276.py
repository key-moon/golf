p=lambda g:[[({6:2,7:7}).get(x,x)for x in r]for r in g]
