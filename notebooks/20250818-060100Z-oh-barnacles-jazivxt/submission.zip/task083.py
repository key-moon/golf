def p(j):A=[r+r[::-1]for r in j];return A+A[::-1]
