p=lambda j:[[[2,4,3][r.index(5)]]*3for r in j]
