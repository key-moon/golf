def p(j):import numpy as A;return A.kron(j,A.ones((2,2))).tolist()
