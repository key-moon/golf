p=lambda j:[[x-2*(x==7)for x in r]for r in j]
