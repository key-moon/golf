p=lambda j:[r[:2]for r in j[:2]]
