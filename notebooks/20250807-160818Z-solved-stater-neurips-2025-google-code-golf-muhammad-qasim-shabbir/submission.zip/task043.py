def p(g):
 E=enumerate
 h=len(g)-1
 w=len(g[0])-1
 for r,R in E(g):
  for c,C in E(R):
   if r>0 and c<h:
    if g[r][w]==5 and g[0][c]==5: g[r][c]=2
 return g