def p(g):
 for i in range(4):
  for j in range(4):g[i][j]+=g[i+4][j]
 g=[[2 if C==0 else 1 for C in R]for R in g]
 g=[[0 if C!=2 else 2 for C in R]for R in g]
 g=g[:4]
 return g