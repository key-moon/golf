def p(m,j=range):
 for c in j(len(m[0])):
  for r in j(len(m)):
   if m[r][c]:break
  else:continue
  for i in j(r,len(m)):m[i][c]=m[r][c]
 return m