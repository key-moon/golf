def p(g):
    return g