def p(g):
 for r in range(4):
  for c in range(4):
   g[r][c]+=g[r+5][c]
   if g[r][c]==3:g[r][c]=0
   elif g[r][c]>0:g[r][c]=3
 return g[:4]