def p(g):
 X=[]
 Y=[list(r)for r in zip(*g[::-1])]
 C=[list(r)for r in zip(*Y[::-1])]
 b=[list(r)for r in zip(*C[::-1])]
 for r in range(len(g)):X.append(g[r]+Y[r])
 for r in range(len(g)):X.append(b[r]+C[r])
 return X