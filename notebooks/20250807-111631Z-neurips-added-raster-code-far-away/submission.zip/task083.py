def p(g):
 t=[r+r[::-1]for r in g]
 return t+t[::-1]