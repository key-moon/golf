def p(j,A=range):
	c=3;E=[]
	for k in A(len(j[0])):
		for W in A(len(j)):
			if j[W][k]:E.append(j[W][k]);break
	E+=[0]*(c*c-len(E));return[E[k*c:(k+1)*c]if k%2==0 else E[k*c:(k+1)*c][::-1]for k in A(c)]