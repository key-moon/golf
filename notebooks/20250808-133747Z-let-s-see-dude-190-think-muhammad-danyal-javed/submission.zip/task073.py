def p(g):
 r=[o[:]for o in g]
 for j in range(5):
  for i in range(5):
   if g[i][j]==1:r[i][j]=0;r[4][j]=1
 return r