def p(g):
 res=[r[:]for r in g]
 for j in range(len(g[0])):
  lc=0
  for i in range(len(g)):
   if g[i][j]!=0:
    lc=g[i][j]
   elif lc!=0:
    res[i][j]=lc
 return res
