def p(g):
 return[[g[i%5][j%6]for j in range(len(g[0])*2)]for i in range(len(g)*1)]
