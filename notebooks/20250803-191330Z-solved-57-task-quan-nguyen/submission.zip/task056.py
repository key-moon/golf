p=lambda g: [[{
    frozenset([(0,0),(0,1),(1,0),(1,2),(2,1)]): 1,
    frozenset([(0,0),(0,2),(1,1),(2,0),(2,2)]): 2,
    frozenset([(0,1),(0,2),(1,1),(1,2),(2,0)]): 3,
    frozenset([(0,1),(1,0),(1,1),(1,2),(2,1)]): 6
 }.get(frozenset((r,c) for r,row in enumerate(g) for c,v in enumerate(row) if v),0)]]