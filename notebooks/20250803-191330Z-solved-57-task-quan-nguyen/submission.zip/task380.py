def p(g):
         return[list(r)for r in zip(*g)][::-1]
        