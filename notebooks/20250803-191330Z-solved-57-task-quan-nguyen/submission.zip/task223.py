def p(g):
 ky, kx = 3, 3
 H, W = len(g), len(g[0])
 return [[ g[i//ky][j//kx] for j in range(W*kx) ] for i in range(H*ky)]
