def p(g):
        h, w = len(g), len(g[0])
        visited = set()
        count = 0
        for r_start in range(h):
            for c_start in range(w):
                if g[r_start][c_start] == 1 and (r_start, c_start) not in visited:
                    count += 1
                    q = [(r_start, c_start)]
                    visited.add((r_start, c_start))
                    head = 0
                    while head < len(q):
                        r, c = q[head]
                        head += 1
                        for dr, dc in [(0,1), (0,-1), (1,0), (-1,0)]:
                            nr, nc = r + dr, c + dc
                            if 0 <= nr < h and 0 <= nc < w and g[nr][nc] == 1 and (nr, nc) not in visited:
                                visited.add((nr, nc))
                                q.append((nr, nc))
        out = [[0]*3 for _ in range(3)]
        for i in range(count):
            out[i//3][i%3] = 2
        return out