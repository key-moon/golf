def p(g):
 ky, kx = 2, 2
 H, W = len(g), len(g[0])
 return [[ g[i//ky][j//kx] for j in range(W*kx) ] for i in range(H*ky)]
