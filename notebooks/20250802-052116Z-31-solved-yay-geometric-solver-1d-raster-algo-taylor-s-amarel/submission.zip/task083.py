def p(g):
 t=[r+r[::-1]for r in g]
 b=[r+r[::-1]for r in g[::-1]]
 return t+b
