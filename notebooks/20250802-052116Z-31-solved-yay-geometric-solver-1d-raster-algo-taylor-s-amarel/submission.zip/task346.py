def p(g):
 tile=[r[:1]for r in g[:1]]
 h,w=1,1
 res=[]
 for i in range(h):
  row=[]
  for j in range(w):
   row.append(tile[i%1][j%1])
  res.append(row)
 return res
