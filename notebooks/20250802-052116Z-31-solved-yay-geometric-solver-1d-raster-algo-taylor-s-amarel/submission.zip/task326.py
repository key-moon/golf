def p(g):
 tile=[r[:2]for r in g[:2]]
 h,w=2,2
 res=[]
 for i in range(h):
  row=[]
  for j in range(w):
   row.append(tile[i%2][j%2])
  res.append(row)
 return res
