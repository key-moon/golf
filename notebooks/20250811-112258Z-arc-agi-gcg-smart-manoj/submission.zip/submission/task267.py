def p(j):A=j[6][0];c=[[r and A for r in X]for X in j];c[6][0]=0;return c
