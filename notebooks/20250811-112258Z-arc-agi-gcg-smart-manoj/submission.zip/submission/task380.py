p=lambda j:[*map(list,zip(*j))][::-1]
