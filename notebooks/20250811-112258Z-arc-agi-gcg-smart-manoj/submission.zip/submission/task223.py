def p(j):import numpy as A;return A.kron(j,A.ones((3,3))).tolist()
