p=lambda g:[[g[i][j]or g[i+6][j]for j in range(11)]for i in range(5)]
