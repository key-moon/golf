def p(j):A={6:2};return[[A.get(x,x)for x in r]for r in j]
