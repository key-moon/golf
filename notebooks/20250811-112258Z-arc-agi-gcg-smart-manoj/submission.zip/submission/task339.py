p=lambda j:[[x for x in sum(j,[])if x]]
