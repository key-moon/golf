p=lambda j:[list(r)for r in zip(*j)]
