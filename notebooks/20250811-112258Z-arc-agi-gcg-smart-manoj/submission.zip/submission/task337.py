p=lambda j:[[A^13*(A in(5,8))for A in A]for A in j]
