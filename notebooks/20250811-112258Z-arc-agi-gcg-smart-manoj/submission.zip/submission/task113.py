p=lambda j:j[:5]+j[:5][::-1]
