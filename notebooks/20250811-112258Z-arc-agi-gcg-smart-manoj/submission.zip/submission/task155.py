p=lambda j:j[::-1]
