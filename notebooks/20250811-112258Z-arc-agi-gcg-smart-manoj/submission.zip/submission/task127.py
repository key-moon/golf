def p(j):
	A=range;c=[A[:]for A in j];E,k=len(j),len(j[0])
	for W in A(1,E,4):
		for l in A(1,k,4):
			J=j[W][l]+5
			for a in A(3):
				for C in A(3):c[W-1+a][l-1+C]=J
	return c
