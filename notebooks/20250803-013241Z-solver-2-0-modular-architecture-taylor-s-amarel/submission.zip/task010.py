def p(g):
 from scipy.ndimage import label
 import numpy as np
 l,n=label(np.array(g)>0)
 res=[[0]*wfor _ in g]
 for i in range(h):
  for j in range(w):
   if l[i,j]>0:
    res[i][j]=l[i,j]%10
    return res