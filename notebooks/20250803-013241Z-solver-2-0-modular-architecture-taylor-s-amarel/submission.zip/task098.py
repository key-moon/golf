def p(g):
 from scipy.ndimage import label
 import numpy as np
 t=np.array(g)
 l,n=label(t>0)
 res=np.zeros_like(t)
 for i in range(1,n+1):
  m=l==i
  pos=np.argwhere(m)
  if len(pos)>0:
   miy,mix=pos.min(axis=0)
   may,max=pos.max(axis=0)
   c=t[m][0]
   res[miy:may+1,mix]=c
   res[miy:may+1,max]=c
   res[miy,mix:max+1]=c
   res[may,mix:max+1]=c
   return res.tolist()