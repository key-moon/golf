def p(g):
 return[[8 if x==5 else 5 if x==8 else x for x in r]for r in g]