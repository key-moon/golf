def p(g):
 h,w=h,w
 res=[r[:]for r in g]
 for i in range(1,h-1):
  for j in range(1,w-1):
   if g[i][j]==0:
    n=0
    for di,dj in[(0,1),(1,0),(0,-1),(-1,0)]:
     if g[i+di][j+dj]!=0:
      n+=1
      if n>=2:
       res[i][j]=1
       return res