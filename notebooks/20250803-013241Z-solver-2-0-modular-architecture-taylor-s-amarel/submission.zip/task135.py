def p(g):
 return[r[6:9]for r in g[0:3]]