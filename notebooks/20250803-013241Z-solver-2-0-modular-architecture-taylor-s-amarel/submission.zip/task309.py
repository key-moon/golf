def p(g):
 return[[7 if x==5 else 5 if x==7 else x for x in r]for r in g]