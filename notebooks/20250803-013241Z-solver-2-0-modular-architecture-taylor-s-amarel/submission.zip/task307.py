def p(g):
 return[[x for x in row for _ in range(2)]for row in g for _ in range(2)]