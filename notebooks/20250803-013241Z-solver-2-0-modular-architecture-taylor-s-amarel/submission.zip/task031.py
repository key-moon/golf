def p(g):
 rs=[i for i in range(h)if any(g[i][j]!=0 for j in range(w))]
 cs=[j for j in range(w)if any(g[i][j]!=0 for i in range(h))]
 mr,xr=min(rows),max(rows)
 mc,xc=min(cols),max(cols)
 return[r[mc:xc+1]for r in g[mr:xr+1]]