def p(g):
 return[r[0:2]for r in g[0:2]]