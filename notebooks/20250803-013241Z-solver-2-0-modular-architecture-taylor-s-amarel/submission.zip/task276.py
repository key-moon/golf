def p(g):
 return[[6 if x==2 else 2 if x==6 else x for x in r]for r in g]