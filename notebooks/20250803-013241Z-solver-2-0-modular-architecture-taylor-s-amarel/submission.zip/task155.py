def p(g):
 h,w=h,w
 res=[[0]*w for _ in range(h)]
 for j in range(w):
  ce=[g[i][j]for i in range(h)if g[i][j]!=0]
  for idx,e in enumerate(ce):
   res[h-1-idx][j]=e
   return res