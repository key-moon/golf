def p(g):
 ih,iw=len(g),len(g[0])
 oh,ow=1,1
 res=[]
 for i in range(oh):
  row=[]
  for j in range(ow):
   si=i*ih//oh
   sj=j*iw//ow
   row.append(g[si][sj])
  res.append(row)
 return res
