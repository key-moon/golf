def p(g):
 return g+g[::-1]
