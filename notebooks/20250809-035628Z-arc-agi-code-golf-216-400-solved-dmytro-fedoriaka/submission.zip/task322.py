def p(m,q=range):
 for c in q(len(m[0])):
  for r in q(len(m)):
   if m[r][c]:break
  else:continue
  for i in q(r,len(m)):m[i][c]=m[r][c]
 return m