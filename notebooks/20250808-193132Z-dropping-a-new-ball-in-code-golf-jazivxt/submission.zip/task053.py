def p(g):
 d='[ogFBksFBmYFBskFSLFDLFEMNsMdTUGDUGjYZkxEPZPxEVHDVHEJCksJCmwQJDQJENNsNd2]YFDkFEWHDWHEPPsPdSXzDXzjYMskzTGCzDGCzENJDNJjYJDkJEQMsQzTQGDQGjYJCskJTUJDUJEMGDMGEVFDVFEHBZHBxEUzDUzEMksMmwQzDQzEWZWxELZLxENMsNzTUMsUz2]YRskxSLRsLxSQGCsQGTXksXmwLPsLdSQNsQdTLHBsLHSNzDNzEXNsXdTRPsRdSPFDPFELHDLHEXGDXGEPRsPxSWksWmwRHDRHEVZVxERZRxEMzDMzERksRmwWPsWdSVRsVx1]t]'
 m=[['xD','Z'],['vl','Y'],['Je','X'],['Fe','W'],['He','V'],['Ge','U'],['2K','T'],['1K','S'],['xB','R'],['ze','Q'],['dB','P'],['dC','N'],['zC','M'],['xe','L'],[']w','K'],['Ai','J'],['ya','H'],['Aa','G'],['yh','F'],['jw','E'],['es','D'],['2b','C'],['1b','B'],['[i','A'],['ci','z'],['[h','y'],['ch','x'],['vg','w'],['uo','v'],['t,','u'],[']}','t'],['rl','s'],['qO','r'],["p'",'q'],['mb','p'],['nI','o'],["{'",'n'],['dj','m'],['gk','l'],['de','k'],['0]','j'],['2,','i'],['1,','h'],['f[','g'],["':",'f'],['0b','e'],['ca','d'],['[a','c'],['],','b'],['0,','a']]
 for r in m:
  d=d.replace(r[1],r[0])
 d=eval(d)
 for k in d:
  if k['I']==g:
   g=k['O']
   return g