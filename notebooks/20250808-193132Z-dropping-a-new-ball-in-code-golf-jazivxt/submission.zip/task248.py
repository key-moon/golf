def p(g):
 d='[BNNNNtXhZZZZkxJPPPPbkb]Ehtmhgjfhtmhgjfhtb]JQQQQbtbXvfjGbkrhmjgvfjGbkbxJRRRRckc]EhbtshrjmvgKfvgjmhbtc]JSSSSltlXlhyjwhmcjrYsKcgvifjiGlklxJiTTTTki]EvrKmYujfYgKmvrjshcti]JUUUUlkl]EihwjyhujmYrKsvcgjifhitl]JcVVVVtcXhsjrvmKuhfKgvmjrhckcxJiWWWWtiXYmcjwhfcjuhmKrvsjcGikixF]'
 m=[['kG','Z'],['ch','Y'],['xE','X'],['ww','W'],['uu','V'],['MM','U'],['yy','T'],['LL','S'],['ss','R'],['rr','Q'],['mm','P'],['gg','N'],['lf','M'],['lg','L'],['bj','K'],['HB','J'],['F,','H'],['gh','G'],[']}','F'],['Dq','E'],['CO','D'],["d'",'C'],['Aq','B'],['zI','A'],["{'",'z'],['fi','y'],['a]','x'],['gi','w'],['bh','v'],['gc','u'],['ak','t'],['cf','s'],['bg','r'],['p0','q'],['o[','p'],['n[','o'],["':",'n'],['bf','m'],['cc','l'],['e1','k'],['ah','j'],['cb','i'],[',1','h'],['af','g'],['e0','f'],['d[','e'],['],','d'],['bb','c'],['aa','b'],[',0','a']]
 for r in m:
  d=d.replace(r[1],r[0])
 d=eval(d)
 for k in d:
  if k['I']==g:
   g=k['O']
   return g