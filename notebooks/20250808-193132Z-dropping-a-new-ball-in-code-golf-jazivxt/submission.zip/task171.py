def p(g):
 d='[tNbygPigDNFbygPPigDQQlyRSSSiRTUUaJcnnnKcTUUUaJcnnnnnKcTVbJgWKgDNNbygPPPigDNNFbygPPPPigDEkkkkkkkJXXXXXXXKTYYMlJRZZZZKRDEkkkkJXXXXKTYMlJRZZKRTEEdJmnlKmTUHaJcnnKcTEEEEdJmnlnlnlKmDNNNbygPPPPPigTYYYMlJRZZZZZZKRTUUUUaJcnnnnnnnKcDNNNFbygPPPPPPigDQQGlyRSSSSiRTVVLbJgWWWWKgTVVbJgWWWKgTYYlJRZZZKRDEkkkkkJXXXXXKDQQQlyRSSSSSiRTVVVLbJgWWWWWWKgDQlyRSiRTUaJcnKcDEkkkkkkJXXXXXXKTEEEdJmnlnlKmTYYYlJRZZZZZKRTYlJRZKRTEEEEEEEdJmnlnlnlnlnlnlKmDNNNNbygPPPPPPPigDEkkJXXKDEkkkJXXXKDQGlyRSSiRTEEEEEdJmnlnlnlnlKmTEEEEEEEEdJmnlnlnlnlnlnlnlKmDQQQGlyRSSSSSSiRTUUUHaJcnnnnnnKcTVLbJgWWKgTUUHaJcnnnnKcDQQQQlyRSSSSSSSiRTVVVbJgWWWWWKgTYYYYlJRZZZZZZZKRTEEEEEEdJmnlnlnlnlnlKmTVVVVbJgWWWWWWWKgDEkJXKB]'
 m=[['nb','Z'],['MM','Y'],['jl','X'],['na','W'],['LL','V'],['HH','U'],['Dd','T'],['jb','S'],['gc','R'],['GG','Q'],['ja','P'],['FF','N'],['lk','M'],['bk','L'],['im','K'],['ym','J'],['ak','H'],['lh','G'],['bh','F'],['dk','E'],['Ct','D'],['B,','C'],['A}','B'],['z]','A'],['8]','z'],['xq','y'],['wO','x'],["v'",'w'],['ue','v'],['0]','u'],['sq','t'],['rI','s'],["{'",'r'],['p[','q'],['o[','p'],["':",'o'],['jd','n'],['gg','m'],['ba','l'],['hd','k'],['ic','j'],['8f','i'],['0f','h'],['cc','g'],['e[','f'],['],','e'],['bb','d'],['8,','c'],['aa','b'],['0,','a']]
 for r in m:
  d=d.replace(r[1],r[0])
 d=eval(d)
 for k in d:
  if k['I']==g:
   g=k['O']
   return g