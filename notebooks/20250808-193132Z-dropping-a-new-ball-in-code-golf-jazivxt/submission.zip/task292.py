def p(g):
 d='[wxeQszR6ZEmjkGlScQYxeRGtEmjTZaLxeUYzcD6ZTmjsGtLxWUgkzeD6XVkGZSeUgsPDGZTMTNSnQokPcRGNVjTNcaLPeQosznR6XiVjYGNaLPUgYzWD6NTMYGliLPWQodszncR6lNVmsGNcaSUsxeDGlEmjEZLPcQgdszWR6NcVjkGXLPQgszeR6NVsGZaSncUodsPWDGNcTMmTlNSWUgdsPcDGXVjENcLPcUokznD6NcTMjsGNScUdsxWDGtTmjdEliSnUosPeDGNTMjdEXiSncQoYPeRGNcVmEXlSeQgkxWRGZVEXLxWQdszcR6liEmjYGtaSWQgYPRGliVdENaLPeUoYzncD6XlVmkGNcJ]'
 m=[['tc','Z'],['dk','Y'],['ll','X'],['ec','W'],['EM','V'],['sy','U'],['s6','T'],['Lz','S'],['aD','R'],['ky','Q'],['xn','P'],['lt','N'],['mm','M'],['Kw','L'],['J,','K'],['H}','J'],[']]','H'],['Ff','G'],['0c','F'],['k6','E'],['Cr','D'],['BO','C'],["A'",'B'],[']h','A'],['0n','z'],['4o','y'],['4i','x'],['vr','w'],['uI','v'],["{'",'u'],['lb','t'],['ak','s'],['q[','r'],['p[','q'],["':",'p'],['gg','o'],['ee','n'],['jj','m'],['if','l'],['h[','k'],['df','j'],['be','i'],['],','h'],['dd','g'],[',6','f'],['cc','e'],['aa','d'],['ab','c'],[',0','b'],[',4','a']]
 for r in m:
  d=d.replace(r[1],r[0])
 d=eval(d)
 for k in d:
  if k['I']==g:
   g=k['O']
   return g