def p(g):
 d='[uTEGUGEVXYZAZKKHJbMNPNFKiRTaMGaPGaFVcRbYbLAbLiKHkbaMSaPSaFkicRgMgPgFqRkTfcGfAcGfkVHkJEcrUcrEkKWkbESUSEkiXbfNfANfKipB]'
 m=[['rL','Z'],['Jf','Y'],['WJ','X'],['cH','W'],['ik','V'],['EA','U'],['bk','T'],['cb','S'],['QD','R'],['1]','Q'],['FA','P'],['rb','N'],['1e','M'],['rf','L'],['ck','K'],['ak','J'],['pD','H'],['bc','G'],['5e','F'],['af','E'],['Cu','D'],['B,','C'],[']}','B'],['zh','A'],['yo','z'],['xO','y'],["w'",'x'],['vd','w'],['qp','v'],['to','u'],['sI','t'],["{'",'s'],['ac','r'],['ii','q'],['5]','p'],['nj','o'],['m[','n'],['l[','m'],["':",'l'],['1,','k'],['hh','j'],['cc','i'],['gf','h'],['bb','g'],['0e','f'],['d[','e'],['],','d'],['5,','c'],['aa','b'],['0,','a']]
 for r in m:
  d=d.replace(r[1],r[0])
 d=eval(d)
 for k in d:
  if k['I']==g:
   g=k['O']
   return g