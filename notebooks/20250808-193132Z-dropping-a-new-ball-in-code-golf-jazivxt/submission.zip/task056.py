def p(g):
 d='[jRt5u5k5C8uS8t8u8T5u5k5t5u5FUkUf1HJSJ8f8VWt4u4k4xw5tERk5D8tJJS8BsXt7u7k7C2uY2t2u2TJ8t8uS8CZt6u6k6xwN3kN3f3HXkXf7V6u6k6t6u6F3tNN3k3DP9kP9f9H1tGUk1D9tPP9k9DWkWf4H4tKWk4Bs7u7k7t7u7F6tMZk6DQYQ2f2HRkRf5V9u9k9t9u9T1u1k1t1u1F2tQQY2DZkZf6V3u3k3t3u3TP9t9u9k9CN3t3u3k3CQ2t2uY2C4u4k4t4u4F7tLXk7BsUt1u1k1xq]'
 m=[['M6','Z'],['2k','Y'],['L7','X'],['K4','W'],['As','V'],['G1','U'],['ys','T'],['8k','S'],['E5','R'],['2,','Q'],['9,','P'],['3,','N'],['6,','M'],['7,','L'],['4,','K'],['8,','J'],['Aw','H'],['1,','G'],['yw','F'],['5,','E'],['Bw','D'],['xs','C'],['v6','B'],['z3','A'],['bv','z'],['o2','y'],['v1','x'],['sg','w'],['bo','v'],['b,','u'],['bf','t'],['rj','s'],['q,','r'],['p}','q'],[']]','p'],['ne','o'],['mO','n'],["l'",'m'],[']a','l'],['fg','k'],['ie','j'],['hI','i'],["{'",'h'],['0,','g'],['a[','f'],['d[','e'],['c[','d'],["':",'c'],[',0','b'],['],','a']]
 for r in m:
  d=d.replace(r[1],r[0])
 d=eval(d)
 for k in d:
  if k['I']==g:
   g=k['O']
   return g