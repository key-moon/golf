def p(g):
 d='[yLzsgqdQWaHjdEQaNQqTXeMQSjaUVzTgZQWhfYUcaVhqTvdXhQMPeYwfUhlVezTvZhcWPaYjdUQaKuczsdqdeaDlfHjEeaNQzTdZeWQaSjdUaVczTgdZhWhlfYjUeaNezTZcWeaSjEhlfKuzsqdcaDfHEcaKucqszdeDlHfEeNeqsgdXcMeSfEhlVqTdXQMhSjdaUcNqsdzdQMHjaEQVeqTgdXhcMPYjaUQVQqTvXheMPcYjdaUhNcqsgXMcHjdaEhVcqTgXhMhlYfUeKuqbdzdcDrbdaEcVQzTvdZheWPcaYwUhfNczsgdZWcaSEhfG]'
 m=[['qR','Z'],['Sw','Y'],['zR','X'],['aM','W'],['Nh','V'],['EP','U'],['sv','T'],['Hw','S'],['dh','R'],['ec','Q'],['ht','P'],['KL','N'],['Dt','M'],['ph','L'],['Jy','K'],['G,','J'],['rs','H'],['F}','G'],[']]','F'],['rj','E'],['Cu','D'],['BO','C'],["A'",'B'],[']i','A'],['aq','z'],['xI','y'],["{'",'x'],['jg','w'],['gg','v'],['pe','u'],['lj','t'],['bg','s'],['k4','r'],['k0','q'],['o2','p'],['n[','o'],['m[','n'],["':",'m'],['ff','l'],['i[','k'],['fb','j'],['],','i'],['ee','h'],['dd','g'],[',4','f'],['cd','e'],['ab','d'],['aa','c'],[',2','b'],[',0','a']]
 for r in m:
  d=d.replace(r[1],r[0])
 d=eval(d)
 for k in d:
  if k['I']==g:
   g=k['O']
   return g