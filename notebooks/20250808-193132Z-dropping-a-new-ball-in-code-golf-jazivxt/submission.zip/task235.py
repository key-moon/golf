def p(g):
 d='[AYwd0fYwd0fpEQfSfULHdofZNjfYNjEUfWfQLNofNuXnuJESfQfWLvYNjfYNjEQfWfQLYZXwZXNoEWfUfSLYNjfYNjfpEQfSfQLYHdjfwHdjfNoEWfUfQLwwd0fwwd0fpESfSfULYNjfwwXNuJEWfSfWLHdofZwXYwJEUfWfWLwHdjfwHdjfpESfUfQLvYwXYwJEQfWfWLvNuXNuJEWfQfWLNuXwwXYNjESfWfSLYNjfYwXnuJEQfSfWLYZd0fwZd0fNoEWfUfULwZXwZXpESfUfSLZNjfZNjfpEUfSfQLZwd0fZwd0fpEUfSfULYwXwwXNoEWfSfSLnuXNuXNoEWfQfSLZwXZwXpEUfSfSLYNjfwNjfNoEWfSfQLvwNjfwNjEWfWfQLHdofHduXnuJEUfQfWLHdud0fZwd0fYNjEUfWfULYwd0fwwd0fNoEWfSfULNofwNjfYNjESfWfQLHdofHdofpEUfQfQLNuXNuXpESfQfSLnuXwwXwNjEWfWfSLZHdjfZZXnuJEUfUfWLnud0fNud0fNoEWfQfULnud0fYwd0fYNjEQfWfULYHdjfYHdjfpEQfUfQLYwXYwXpEQfSfSLvwwXwwJEWfWfWLNofNofpESfQfQLYZd0fYZd0fpEQfUfULwZd0fwZd0fpESfUfULnuXnuXpEQfQfSLvvpEQfQfQLNofwwXYwJESfWfWLZZd0fZZd0fpEUfUfULNud0fNud0fpESfQfULHduXZwXYNjEUfWfSLvnuXnuJEQfQfWLZZXZZXpEUfUfSLwHdjfwZXnuJESfUfWLYHdjfYZXnuJEQfUfWLYHdjfwZXNuJEWfUfWLwNjfwwXnuJESfSfWLYZXYZXpEQfUfSLnud0fnud0fpEQfQfULZNjfZwXnuJEUfSfWLNud0fwwd0fYNjESfWfULHduXHduXpEUfQfSLnuXYwXYNjEQfWfSLHdud0fHdud0fpEUfQfULvNofNoEWfQfQLnud0fwwd0fwNjEWfWfULwwXwwXpESfSfSLZHdjfZHdjfpEUfUfQLwNjfwNjfpESfSfQG]'
 m=[['Hc','Z'],['bu','Y'],['Jf','X'],['V4','W'],['tt','V'],['T3','U'],['ss','T'],['R8','S'],['rr','R'],['P2','Q'],['qq','P'],['Md','N'],['ia','M'],['KA','L'],['G,','K'],['i5','J'],['dc','H'],['F}','G'],[']]','F'],['Dm','E'],['CO','D'],["B'",'C'],[']e','B'],['zv','A'],['ym','z'],['xI','y'],["{'",'x'],['ig','w'],['pf','v'],['bc','u'],['4,','t'],['3,','s'],['8,','r'],['2,','q'],['no','p'],['hj','o'],['bh','n'],['l[','m'],['k[','l'],["':",'k'],['a5','j'],['gc','i'],['bd','h'],['ac','g'],['e[','f'],['],','e'],['cb','d'],['0,','c'],['aa','b'],['5,','a']]
 for r in m:
  d=d.replace(r[1],r[0])
 d=eval(d)
 for k in d:
  if k['I']==g:
   g=k['O']
   return g