def p(g):
 d='[njQG[Czv[Ez]HTJA3NKVMtENxXGdC]vdE]]xTGA3uvA8u]HZbacJt6yoKXMdE]oHXJdC]oHQJ[CzoKTMA8NHVJtCNKZbacMt7yoxZbacGt6yvt7y]xVGtCuvtEu]KQM[Ezo}]'
 m=[['Y,','Z'],['[2','Y'],['Wu','X'],['A2','W'],['Uz','V'],['d2','U'],['S]','T'],['R2','S'],['db','R'],['Py','Q'],['t2','P'],['uo','N'],['Lw','M'],['vk','L'],['si','K'],[']w','J'],['xg','H'],['Fi','G'],['oq','F'],['D7','E'],['8l','D'],['B6','C'],['3l','B'],['da','A'],['lc','z'],[',e','y'],['sj','x'],['qj','w'],[',g','v'],[',c','u'],['[a','t'],['rn','s'],['},','r'],['pO','q'],[",'",'p'],[',k','o'],['mI','n'],["{'",'m'],[',a','l'],['f]','k'],['ig','j'],['h[','i'],["':",'h'],['f,','g'],['de','f'],['bc','e'],['[b','d'],['0]','c'],['aa','b'],['0,','a']]
 for r in m:
  d=d.replace(r[1],r[0])
 d=eval(d)
 for k in d:
  if k['I']==g:
   g=k['O']
   return g