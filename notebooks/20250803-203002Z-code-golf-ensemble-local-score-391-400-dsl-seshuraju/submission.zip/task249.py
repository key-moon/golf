def p(input):
 return[row*2 for row in input]