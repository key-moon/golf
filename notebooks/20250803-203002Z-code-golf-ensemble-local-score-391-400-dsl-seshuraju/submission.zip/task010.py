def p(g):
 from scipy.ndimage import label
 import numpy as np
 arr=np.array(g)
 labeled, n=label(arr>0)
 res=np.zeros_like(arr)
 for i in range(1, n+1):
  res[labeled==i]=i
 return res.tolist()
