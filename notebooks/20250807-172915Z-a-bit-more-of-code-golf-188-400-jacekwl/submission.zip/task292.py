def p(g):
 for r in g:r[::3]=[6 if v==4 else v for v in r[::3]]
 return g