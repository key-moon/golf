def p(g):
 h, w = len(g), len(g[0])
 ry, rx = 1, 2
 return [[g[i % h][j % w] for j in range(w * rx)]
         for i in range(h * ry)]