def p(g):
 return g[::-1]