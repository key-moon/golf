def p(g):
 return [row[:2] for row in g[:2]]