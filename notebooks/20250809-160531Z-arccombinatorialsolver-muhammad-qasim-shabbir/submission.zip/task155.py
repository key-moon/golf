def p(g):
    res = g
    res = g
    res = g[::-1]
    return res