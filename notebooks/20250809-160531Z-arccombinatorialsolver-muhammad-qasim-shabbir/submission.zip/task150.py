def p(g):
    res = g
    res = g
    res = [row[::-1] for row in g]
    return res