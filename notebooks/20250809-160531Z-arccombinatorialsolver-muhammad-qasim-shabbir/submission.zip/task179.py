def p(g):
    res = g
    res = g
    res = [list(row) for row in zip(*g[::-1])]
    res = g[::-1]
    return res