def p(g):
    return [row[2:5] for row in g[1:4]]