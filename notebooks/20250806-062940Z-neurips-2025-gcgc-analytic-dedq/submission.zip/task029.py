def p(g):
    return [row[5:13] for row in g[4:10]]