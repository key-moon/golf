def p(g):
    return [row[3:7] for row in g[2:6]]