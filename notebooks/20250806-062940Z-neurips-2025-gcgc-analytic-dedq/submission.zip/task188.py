def p(g):
    return [row[0:4] for row in g[0:4]]