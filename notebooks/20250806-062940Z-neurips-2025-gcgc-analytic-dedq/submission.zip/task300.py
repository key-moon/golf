def p(g):
    return [row[1:4] for row in g[1:5]]