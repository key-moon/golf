def p(g):
    return [row[3:5] for row in g[3:5]]