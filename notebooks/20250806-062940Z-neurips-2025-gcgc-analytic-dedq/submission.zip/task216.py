def p(g):
    return [row[6:12] for row in g[13:18]]