def p(g):
    return [row[1:6] for row in g[1:6]]