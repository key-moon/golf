def p(g):
    return [row[3:8] for row in g[3:8]]