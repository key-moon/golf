def p(g):
    return [row[5:12] for row in g[5:12]]