def p(g):
    return [row[0:10] for row in g[11:21]]