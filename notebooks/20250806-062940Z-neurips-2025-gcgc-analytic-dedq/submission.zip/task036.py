def p(g):
    return [row[17:20] for row in g[10:15]]