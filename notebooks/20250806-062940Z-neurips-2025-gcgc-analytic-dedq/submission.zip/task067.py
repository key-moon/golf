def p(g):
    return [row[0:3] for row in g[0:3]]