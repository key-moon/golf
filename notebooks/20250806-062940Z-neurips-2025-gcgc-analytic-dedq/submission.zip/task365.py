def p(g):
    return [row[6:10] for row in g[0:5]]