def p(g):
    return [row[0:3] for row in g[6:9]]