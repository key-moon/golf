def p(g):
    H,W=len(g),len(g[0])
    Ho,Wo=2*H,2*W
    canvas=[[0]*Wo for _ in range(Ho)]
    for r in range(H):
        for c in range(Wo):
            canvas[r][c]=g[r][c%W]
    return canvas
