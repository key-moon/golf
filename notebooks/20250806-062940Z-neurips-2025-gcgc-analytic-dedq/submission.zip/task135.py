def p(g):
    return [row[6:9] for row in g[0:3]]