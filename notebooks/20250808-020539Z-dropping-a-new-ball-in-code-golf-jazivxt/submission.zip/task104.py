def p(g):
 d='[FdZhRvLzBBTPblUVWKggAAkXpWPVjaURgXuanAtTPdZhRvLzBBTPbZhdQggBBLLyPblUVWKggAAkXpWPVjaURgXuanAtTM]'
 m=[['YG','Z'],['hc','Y'],['Cx','X'],['3]','W'],['ac','V'],['Gj','U'],['Sy','T'],['kg','S'],['bQ','R'],['yK','Q'],['NF','P'],['M,','N'],[']}','M'],['zz','L'],['Js','K'],['HO','J'],["e'",'H'],['2,','G'],['Es','F'],['DI','E'],["{'",'D'],['xx','C'],['ww','B'],['tt','A'],['hv','z'],['0]','y'],['ug','x'],['ki','w'],['ig','v'],['pj','u'],['ln','t'],['r[','s'],['q[','r'],["':",'q'],['oc','p'],['ad','o'],['ma','n'],['ib','m'],['ha','l'],['hg','k'],['3f','j'],['dd','i'],['0f','h'],['bb','g'],['e[','f'],['],','e'],['cc','d'],['3,','c'],['aa','b'],['0,','a']]
 for r in m:
  d=d.replace(r[1],r[0])
 d=eval(d)
 for k in d:
  if k['I']==g:
   g=k['O']
   return g