def p(g):
 d='[GzzzzanaMiWWWWnbRAAAAcncMiSuiUjiSuiUjiSdRBBBBcancaMvjowdndwuomvjowdndbRgCCCCngMidSkjidUuvmTjvUuidSkRgVVVVVVVVganggaMkXjkTmkvukodmXkjTkmvkuokdwkknkkbRAAAAcncMiSuiUjiSuiUjiSdRgYYYYYYYYcngcMvdmTuXmkojXmTuvdUkjikSkdRgZZZZZZZZgnggMkvmkTjkvmkouXdmTkjvkUkuikdSkkRyyyyyyyVangaMikjodmvuTmXjTmvuodwknkbRBBBBcancaMvjowdndwuomvjowdndbRzzzzanaMiWWWWnbRgtgtgtgtgtgtgtgtgcangcaMXukomkvjkomXuTdmvkjokwkdnkdbRgCCCCngMidSkjidUuvmTjvUuidSkP]'
 m=[['gp','Z'],['cp','Y'],['ki','X'],['nw','W'],['yg','V'],['mo','U'],['do','T'],['bn','S'],['QG','R'],['P,','Q'],['N}','P'],[']]','N'],['L8','M'],['Ks','L'],['JO','K'],["H'",'J'],[']e','H'],['F0','G'],['Es','F'],['DI','E'],["{'",'D'],['pp','C'],['tt','B'],['xx','A'],['ll','z'],['gl','y'],['ch','x'],['mi','w'],['di','v'],['dj','u'],['cl','t'],['r[','s'],['q[','r'],["':",'q'],['hg','p'],['bi','o'],['f1','n'],['bj','m'],['ah','l'],['dd','k'],['f8','j'],[',1','i'],['f0','h'],['cc','g'],['e[','f'],['],','e'],['bb','d'],['aa','c'],[',8','b'],[',0','a']]
 for r in m:
  d=d.replace(r[1],r[0])
 d=eval(d)
 for k in d:
  if k['I']==g:
   g=k['O']
   return g