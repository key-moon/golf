def p(g):
 d='[uSEUAUVWHfXAXJJWbMNPNFJiRSaMYPYFVRbHfbLAbLiJKSEUAUVKSaMYPYFVRHHfXAXJJKkbaMZaPZaFkicRgMgPgFrRkSfcGfAcGfkTKkHEcqEAcqEkJcWbMNPNFJiRkbEZEAZEkicWbfNfANfJipB]'
 m=[['cb','Z'],['Ga','Y'],['qL','X'],['KH','W'],['Tc','V'],['GE','U'],['ik','T'],['bk','S'],['QD','R'],['1]','Q'],['FA','P'],['qb','N'],['1e','M'],['qf','L'],['pD','K'],['ck','J'],['ak','H'],['bc','G'],['5e','F'],['af','E'],['Cu','D'],['B,','C'],[']}','B'],['zh','A'],['yo','z'],['xO','y'],["w'",'x'],['vd','w'],['rp','v'],['to','u'],['sI','t'],["{'",'s'],['ii','r'],['ac','q'],['5]','p'],['nj','o'],['m[','n'],['l[','m'],["':",'l'],['1,','k'],['hh','j'],['cc','i'],['gf','h'],['bb','g'],['0e','f'],['d[','e'],['],','d'],['5,','c'],['aa','b'],['0,','a']]
 for r in m:
  d=d.replace(r[1],r[0])
 d=eval(d)
 for k in d:
  if k['I']==g:
   g=k['O']
   return g