def p(g):
 d='[oGUCWgXkQP]RSYZMGAKwy2xCdEjgdA]wPjCSxgy8,Q[BbacqG6,HfLZMGAYy2xMldAjfwvUCWgXkQyBcRdEjfwy2xCdEjgdA]JvBeRWfLPjMly8KwPjCSxgy8,QP]RSKJTkcqGEY[BbamMG7,Hfw[BbamCv6,Hgv7,ewZCvExgvA,cLvUMlXFfr]'
 m=[['TF','Z'],['KL','Y'],['[A','X'],['VF','W'],['[E','V'],['BH','U'],['d2','T'],['y3','S'],['ql','R'],['cJ','Q'],['N2','P'],['db','N'],['gu','M'],['ti','L'],['xf','K'],['wg','J'],['e,','H'],['lv','G'],['km','F'],['D6','E'],['3k','D'],['ui','C'],['2,','B'],['z7','A'],['8k','z'],['da','y'],[',m','x'],['tl','w'],['[a','v'],['fq','u'],['so','t'],['r,','s'],[']}','r'],['pO','q'],["j'",'p'],['nI','o'],["{'",'n'],['c,','m'],['ig','l'],[',a','k'],['],','j'],['h[','i'],["':",'h'],['f,','g'],['de','f'],['bc','e'],['[b','d'],['0]','c'],['aa','b'],['0,','a']]
 for r in m:
  d=d.replace(r[1],r[0])
 d=eval(d)
 for k in d:
  if k['I']==g:
   g=k['O']
   return g