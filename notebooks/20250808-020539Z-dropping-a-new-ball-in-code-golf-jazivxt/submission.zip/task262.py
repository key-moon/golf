def p(g):
 d='[qZGGUHHVMSNTKGRLHWGMRHNWGMRHNWMKUNLVKMULNVZKGPLHQMGRNHxz]'
 m=[['YT','Z'],['XH','Y'],['GS','X'],['xF','W'],['nF','V'],['lv','U'],['LQ','T'],['KP','S'],['rJ','R'],['DF','Q'],['BJ','P'],['Dc','N'],['Bk','M'],['xc','L'],['rk','K'],['0v','J'],['nc','H'],['lc','G'],['Eq','F'],['z,','E'],['C2','D'],['jj','C'],['Ab','B'],['5,','A'],['y}','z'],[']]','y'],['w4','x'],['ii','w'],['uh','v'],['tO','u'],["s'",'t'],[']a','s'],['e,','r'],['ph','q'],['oI','p'],["{'",'o'],['m3','n'],['dd','m'],['be','l'],['0c','k'],['2,','j'],['4,','i'],['g[','h'],['f[','g'],["':",'f'],['b5','e'],['3,','d'],['a[','c'],['0,','b'],['],','a']]
 for r in m:
  d=d.replace(r[1],r[0])
 d=eval(d)
 for k in d:
  if k['I']==g:
   g=k['O']
   return g