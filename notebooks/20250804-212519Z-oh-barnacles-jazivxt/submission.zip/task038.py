def p(g):
 P=0
 h,w=len(g),len(g[0])
 for r in range(h-1):
  for c in range(w-1):
    q=g[r][c:c+2]+g[r+1][c:c+2]
    if q==[1,1,1,1]:P+=1
 return [[0 if i+1>P else 1 for i in range(5)]]
