def p(g):
 X=[]
 for i in range(3):
  S = list(set(g[i]))
  if len(S)>1:X.append([0]*3)
  else:X.append([5]*3)
 return X
