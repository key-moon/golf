def p(g):return[g[i][6:9]for i in range(0,3)]
