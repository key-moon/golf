def p(g):
 E=enumerate
 for r,R in E(g):
  i,X,S=0,[],False
  for c,C in E(R):
   if C>0:
    X=[C,5]*20
    S=True
   if S:
    g[r][c]=X[i]
    i+=1
 return g
