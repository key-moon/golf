def p(g):
 return [row[:] for row in g]
