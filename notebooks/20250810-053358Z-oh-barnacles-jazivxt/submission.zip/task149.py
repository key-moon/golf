def p(g):
 q=range
 r=[[0]*3for _ in q(3)]
 for i in q(3):
  for j in q(3):
   c=0
   for x in q(3):
    for y in q(3):
     if g[i*4+x][j*4+y]==6:c+=1
   r[i][j]=1if c>=2else 0
 return r
