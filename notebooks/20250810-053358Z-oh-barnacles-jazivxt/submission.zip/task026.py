p=lambda j:[[8*(not A|B)for(A,B)in zip(A,A[4:])]for A in j]
