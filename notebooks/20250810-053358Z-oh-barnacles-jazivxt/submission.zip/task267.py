def p(g):
 E=enumerate
 X=g[-1][0]
 g[-1][0]=0
 for r,R in E(g):
   for c,C in E(R):
    if C>0:g[r][c]=X
 return g
