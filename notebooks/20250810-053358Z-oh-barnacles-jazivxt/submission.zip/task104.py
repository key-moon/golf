def p(g):
 d='[FTblGqKTsBwCCaWYhdZAADDQdYkSiDyAAWjGlbaZktCxBBaM]'
 m=[['Sg','Z'],['Xb','Y'],['hG','X'],['Vc','W'],['UQ','V'],['mg','U'],['p3','T'],['Rg','S'],['Kz','R'],['Pz','Q'],['NF','P'],['M,','N'],['L}','M'],[']]','L'],['JO','K'],["H'",'J'],[']e','H'],[',2','G'],['EI','F'],["{'",'E'],['yy','D'],['xx','C'],['ww','B'],['vv','A'],['p0','z'],['mi','y'],['qt','x'],['ls','w'],['ug','v'],['hi','u'],['ai','t'],['rg','s'],['db','r'],['ak','q'],['o[','p'],['n[','o'],["':",'n'],['hg','m'],['aj','l'],['hc','k'],['f3','j'],['dd','i'],['f0','h'],['cc','g'],['e[','f'],['],','e'],['bb','d'],['aa','c'],[',3','b'],[',0','a']]
 for r in m:d=d.replace(r[1],r[0])
 d=eval(d)
 for k in d:
  if k['I']==g:
   g=k['O']
   return g
