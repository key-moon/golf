def p(g):
 f=[i for s in g for i in s]
 f=[c for c in set(f) if c not in [0,5]][0]
 g=[[f if C==5 else 0 for C in R] for R in g]
 return g
