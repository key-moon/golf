p=lambda g:[[r for j,r in enumerate(g)if sum(r)and j%3==i%3][0]for i in range(len(g))]
