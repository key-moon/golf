p=lambda g:[[1if[g[i][0]for i in range(3)]==[g[i][2]for i in range(3)]else 7]]
