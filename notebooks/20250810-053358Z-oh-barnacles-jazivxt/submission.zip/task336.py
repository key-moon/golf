def p(g):
 d='[NGmDmKKPaiHSGmDmLLPgiZYGHnmPaimKBDSxFZZmPgimLCDYGmoVbtaVbtaVbrbhbtaVboVuSGmoVbcWVbcWVbsk8fbcWVboVuYGmaopatapataparmatapaocHSGmaopacWpacWpasg8fbacWpaocHYGmDmKBPaiHnSGmDmLCPgiZJYGnmDmKBPaiHSGnmDmLCPgiZYxbDmKKPaiHHSxbDmLLPgiZZYGjaDbharVarVarbjarVaDbhuSGjaDbhasVasVasW8fasVaDbhuYGnmPaimKKDnSxFZmPgimLLDnYGnmPaimKBDHSxFZmPgimLCDHYGmPaimKKDHSxFJmPgimLLDHYGmPaimKBDHnSxFJmPgimLCDHnYGmDmKrbhbBDHSGmDmLsk8fbCDHYGmaDhbarchbarchlchbarchbaDhuSGmaDhbaschbaschqqchbaschbaDhuYGjdoc5fdr5fdr5fla5fdr5fdoc5fuSGjdoc5fds5fds5fqqg5fds5fdoc5fuYGmoVbtaVbtaVdbVbtaVboVuSGmoVbcWVbcWVqkVbcWVboVuYGmDmBrcjdbapBDHSGmDmCscjqWpCDHYxlmDmKKPaiHnSxlmDmLLPgiZJYxbDmKBPaiHHnSxbDmLCPgiZZJYGHmPaimKBDnSxFZJmPgimLCDnYGjDbjrtjrtjclhrtjDbHSGjDbjstjstjsq8fstjDbHYxlmDmKBPaiHHSxlmDmLCPgiZZYGjaotjatatjatatjarbjatatjaotHSGjaotjacWtjacWtjasW8facWtjaotHYGjAo5fAta5fAta5fla5fAta5fAo5fuSGjAo5fAcW5fAcW5fqqg5fAcW5fAo5fuYGmaopatapatacjdbapatapaocHSGmaopacWpacWcjqWpacWpaocHYGjdochdtachdtachlchdtachdochuSGjdochdcWchdcWchqqchdcWchdochuYGHmPaimKKDSxFZJmPgimLLDYGjorhtarhtarhclhtarhorhuSGjorhcWrhcWrhsq8fcWrhorhuU]'
 m=[['JJ','Z'],['XN','Y'],['U,','X'],['kg','W'],['th','V'],['T}','U'],['z]','T'],['RO','S'],["Q'",'R'],['ze','Q'],['ic','P'],['MI','N'],["{'",'M'],['CC','L'],['BB','K'],['jF','J'],['nn','H'],['xu','G'],['Eb','F'],['Ag','E'],['oi','D'],['sp','C'],['rp','B'],['da','A'],['y]','z'],['a0','y'],['w[','x'],['v[','w'],["':",'v'],['ln','u'],['cb','t'],['cq','s'],['cd','r'],['kk','q'],['cm','p'],['ii','o'],['jl','n'],['jb','m'],['dd','l'],['gg','k'],['ah','j'],['cc','i'],['0f','h'],['8,','g'],['e[','f'],['],','e'],['bb','d'],['5,','c'],['aa','b'],['0,','a']]
 for r in m:
  d=d.replace(r[1],r[0])
 d=eval(d)
 for k in d:
  if k['I']==g:
   g=k['O']
   return g
