def p(g):
 g=[i for s in g for i in s]
 return [[i for i in g if i>0]]
