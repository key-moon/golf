def p(g):
 d='[AbZLTUbZLjGHSZNPxkiWgUPPPXjYPxNsmBLgUQQjXYmNsmBiWgFQQjXYmNQjTUQjXYQmNbRkLTFbuRLGjHRNbRBiWgFbuuRLGjHnNbRkiWgUbuRLGjHRNPxiWTFPPXjYPPxNbuuWTFbRLGjHuRNbZkLTFbSZLjGHZNPxBiWgFPPPPXjYxNbRLTUbRLGjHuRNsmkiWgUQsjXYsmNsmiWTFQjXYQmNbZBLgUbSSZLjGHvNsmkLTFQsjXYsmNbRBLgUbuuRLGjHnK]'
 m=[['Sv','Z'],['ht','Y'],['hG','X'],['VH','W'],['bh','V'],['kF','U'],['gB','T'],['vi','S'],['un','R'],['ss','Q'],['xe','P'],['MA','N'],['K,','M'],['ej','L'],['J}','K'],['r]','J'],['tb','H'],['4,','G'],['Eq','F'],['DO','E'],["C'",'D'],['rc','C'],['kk','B'],['zq','A'],['yI','z'],["{'",'y'],['wg','x'],['af','w'],['bf','v'],['ni','u'],['2d','t'],['me','s'],['0]','r'],['p[','q'],['o[','p'],["':",'o'],['fb','n'],['la','m'],['gf','l'],['ig','k'],['hh','j'],['eb','i'],['2,','h'],['ba','g'],['8,','f'],['0d','e'],['c[','d'],['],','c'],['aa','b'],['0,','a']]
 for r in m:d=d.replace(r[1],r[0])
 d=eval(d)
 for k in d:
  if k['I']==g:
   g=k['O']
   return g
