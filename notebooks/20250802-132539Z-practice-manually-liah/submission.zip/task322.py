def p(m):
 for c in range(len(m[0])):
  for r in range(len(m)):
   if m[r][c]:break
  else:continue
  for i in range(r,len(m)):m[i][c]=m[r][c]
 return m
