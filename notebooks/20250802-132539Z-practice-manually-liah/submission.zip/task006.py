def p(m):
 o=[]
 for r in m:
  try:
   s=r.index(5);l,R=r[:s],r[s+1:]
   o+=[[2if l[i]==R[i]==1else l[i]+R[i]if l[i]==R[i]else 0for i in range(s)]]
  except:o+=[[]]
 return o
