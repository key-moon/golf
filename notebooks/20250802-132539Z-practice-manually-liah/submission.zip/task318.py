def p(m):
    return [[3 if m[r][c] or m[r+5][c] else 0 for c in range(4)] for r in range(4)]
