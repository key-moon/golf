def p(m):
 for r in m:
  for v in r:
   if v and v-5:
    r[:]=[v*(x==5)+x*(x!=5)for x in r];break
 return m

