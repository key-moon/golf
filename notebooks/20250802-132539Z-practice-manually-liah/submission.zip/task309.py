def p(m):
 for i in m:
  for j in range(len(i)):
   if i[j]==7:i[j]=5
 return m
