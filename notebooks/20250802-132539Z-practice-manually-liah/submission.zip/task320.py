def p(m):
 r=len(m);c=len(m[0]);r_=[i[:]for i in m]
 for j in range(c):
  nz=[i for i in range(r)if m[i][j]];l=len(nz)//2
  for i in range(l):r_[nz[-1-i]][j]=8
 return r_
