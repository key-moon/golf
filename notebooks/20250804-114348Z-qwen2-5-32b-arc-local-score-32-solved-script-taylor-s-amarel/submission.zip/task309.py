def p(g):
 m={7:5}
 return[[m.get(x,x)for x in r]for r in g]
