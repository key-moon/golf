def p(g):
 return[[(g[r%3][c%3]if g[r//3][c//3]else 0)for c in range(9)]for r in range(9)]