def p(g):
 return[row[:1]for row in g[:1]]
