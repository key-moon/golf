def p(g):
 k=next(i for i,v in enumerate(g[0])if v==1)
 l=[r[:k]for r in g]
 r=[r[k+1:]for r in g]
 return[[3 if l[i][j]==r[i][j]==0 else 0 for j in range(len(l[0]))]for i in range(len(g))]