p=lambda g:[[2if i>0and g[i-1][j]==8else 0for j in range(len(g))]for i in range(len(g))]

