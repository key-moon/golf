def p(g):
 g = [R[::-1] + R for R in g]
 fg = [g[2],g[1],g[0]]
 g = fg+g+fg
 return g
