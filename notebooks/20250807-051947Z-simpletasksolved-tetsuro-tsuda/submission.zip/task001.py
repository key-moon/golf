def p(g):
 return [[0 if g[i//3][j//3]==0 else g[i%3][j%3] for j in range(9)] for i in range(9)]