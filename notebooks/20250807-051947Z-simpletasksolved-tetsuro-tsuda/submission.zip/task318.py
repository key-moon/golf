def p(g):
 for i in range(4):
  for j in range(4):
   g[i][j]+=g[i+5][j]
 g=[[3 if C>0 else 0 for C in R] for R in g]
 g=g[:4]
 return g
