def p(g):
 R=range
 r=[[0]*4for _ in R(4)]
 b=[(0,0),(4,4),(4,0),(0,4)]
 for x,y in b:
  for i in R(4):
   for j in R(4):
    if g[x+i][y+j]:r[i][j]=g[x+i][y+j]
 return r