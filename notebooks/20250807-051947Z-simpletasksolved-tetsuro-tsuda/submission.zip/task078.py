def p(g):
 q=range
 h,w=len(g),len(g[0])
 res=[[0]*w for _ in q(h)]
 for j in q(w):
  nz=[g[i][j]for i in q(h)if g[i][j]!=0]
  for k,v in enumerate(nz):
   res[k][j]=v
 return res
