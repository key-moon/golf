def p(g):
    return[[5]*3if len(set(r))==1else[0]*3for r in g]