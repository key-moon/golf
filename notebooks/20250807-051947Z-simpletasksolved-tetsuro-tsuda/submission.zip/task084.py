def p(g):
 n=len(g)
 r=[row[:]for row in g]
 for i in range(n):
  for j in range(n):
   if i==n-1and j>0:r[i][j]=4
   if i+j==n-1and j>0:r[i][j]=2
 return r