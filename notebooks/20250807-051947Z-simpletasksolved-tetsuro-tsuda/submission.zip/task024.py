def p(g):
 e=enumerate
 r=[[0]*len(g[0])for _ in g]
 for i,o in e(g):
  for j,v in e(o):
   if v==2:
    for k in range(len(g)):r[k][j]=2
 for i,o in e(g):
  for j,v in e(o):
   if v in[1,3]:
    r[i]=[v]*len(g[0])
 return r