def p(g):return[r[::-1]for r in g]
