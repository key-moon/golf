def p(g):return [[5 if x == 7 else x for x in row] for row in g]
