def p(g):return [[5 if x==8 else 8 if x==5 else x for x in r] for r in g]
