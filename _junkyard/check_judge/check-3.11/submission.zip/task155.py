def p(g):
  f"{"test"}"
  return [[*map(float,r)] for r in g[::-1]]
