def p(g):
  return [*map(tuple,g[::-1])]
