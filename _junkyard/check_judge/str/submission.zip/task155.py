def p(g):
  return [[*map(str,r)] for r in g[::-1]]
