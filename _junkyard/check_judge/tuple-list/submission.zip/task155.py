def p(g):
  return tuple(g[::-1])
